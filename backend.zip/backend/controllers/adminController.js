const Admin = require("../models/Admin");

const User = require("../models/User");



module.exports.createAdmin = async function (req, res) {

    const checkAdmin = await Admin.findOne({ emailId: req.body.emailId });

    if (checkAdmin) {
        return res.json({ msg: "admin Already exists", status: false });
    }

   

    const admin = await Admin.create({
        username: req.body.username,
        password: req.body.password,
        emailId: req.body.emailId
    });


    return res.json({ msg: "Created  successfully", status: true });
};

module.exports.login = async function (req, res) {
    const checkAdmin = await Admin.findOne({ emailId: req.body.emailId });
    if(req.body.emailId==checkAdmin.emailId && req.body.password==checkAdmin.password){
        return res.json({ "res": "loggedin" })
        
    }
    else{
         res.json({ msg: "invalid credentials", status: false });
    }
    
};
module.exports.logout = function (req, res) {
    return res.json({ "msg": "logged out" })
};


module.exports.getUser = async function (req, res) {

    const checkUser = await User.findOne({ emailId: req.body.emailId });

    if (checkUser) {
        return res.json(checkUser);
    }
    else res.json({ msg: "user not found", status: false });
};


module.exports.updateUser = async function (req, res) {

    const checkUser = await User.findOneAndUpdate({ emailId: req.body.emailId },
        req.body);

    if (checkUser) {
        return res.json({ msg: "updated", status: true });
    }
    else res.json({ msg: "user not found", status: false });
};

module.exports.deleteUser = async function (req, res) {

    try {
        const user = await User.findOneAndDelete({ emailId: req.body.emailId });
        if (user) {
            res.send("deleted user successfully");
        } else {
            res.send("Invalid user");
        }
    } catch {
        res.send("error in deleting user");
    }

};





